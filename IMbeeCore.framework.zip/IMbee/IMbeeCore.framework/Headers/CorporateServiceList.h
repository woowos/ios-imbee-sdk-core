//
//  CorporateServiceList.h
//  IMbee
//
//  Created by Jordi Masip i Riera on 16/3/17.
//  Copyright © 2017 IMbee. All rights reserved.
//

#import "CorporateContactList.h"

@interface CorporateServiceList<__covariant ObjectType:IMContact *> : CorporateContactList

@end
